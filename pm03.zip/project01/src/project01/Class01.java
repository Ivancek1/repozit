package project01;

public class Class01 {

	public static void main(String[] args) {
		// TODO Автоматически созданная заглушка метода
		System.out.println("Иван Горовенка Павлович");
		System.out.println("Г");
		System.out.println("о");
		System.out.println("р");
		System.out.println("о");
		System.out.println("в");
		System.out.println("е");
		System.out.println("н");
		System.out.println("к");
		System.out.println("о");
		int age = 19;
		System.out.println("Иван "+ age );
	}

}
